-- Adminer 4.7.8 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `tebecity` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `tebecity`;

DROP TABLE IF EXISTS `about`;
CREATE TABLE `about` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `description` longtext,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `about` (`id`, `title`, `description`, `createdAt`) VALUES
(1,	'<h3>Developing a Better City</h3>',	'<p>The goal of the project is to encourage residents, workers, students in the cities, to help develop a better city. Using mobile connected digital technologies, with the support of an application created for this purpose, users can in a geolocalized way, enter information about the neighborhood, feeding a database with information about the deficient infrastructure in the following areas:</p>\r\n<ul>\r\n<li>Drinking Water</li>\r\n<li>Sewage Collection and Treatment</li>\r\n<li>Street lighting</li>\r\n<li>Sidewalks</li>\r\n<li>Asphalt</li>\r\n<li>Urban Cleaning</li>\r\n</ul>\r\n<p>All the information provided in real time will be analised by the public sector deisgned for the porpue and provide status. The citizen can followup through the app all the issues reported. The expected result of the project is collect enough information that can help in the formulation of public policies by these executive bodies.</p>\r\n<h4>Admin Controll</h4>\r\n<p>An admin area was develop to help manage all the data collected. using a map feature, all order opend can be tracked and filter. Reports can be developed to understand what the better and worse services reported by the citizans. Also a feature for feedback was develop in order to collect additional information about the app or any other concerns.</p>\r\n<h4>News Interface</h4>\r\n<p>For those who are admins or contributer, the home page contains a list of the latest news and small report views. It helps track the latest incomes and updated.</p>\r\n<h4>Search tool</h4>\r\n<p>With the report user itnerface is not enough to understand all the data collected, the search screen also can provided detail filters. All the incomes data can be used as filters, and the result exported for external analisis.</p>\r\n<h4>Technical information tool</h4>\r\n<p>The solution was developing using a range of technologies available in the markets considering free open source and best stardard for software development.</p>\r\n<dl>\r\n  <dt>Backend API</dt>\r\n  <dd>C#</dd>\r\n  <dd>DotNet Core 3.1</dd>\r\n  <dd>Docker running in Linux</dd>\r\n  <dd>MySql</dd>\r\n  <dt>Admin Site</dt>\r\n  <dd>Angular 11</dd>\r\n  <dd>Bulma css</dd>\r\n  <dt>App</dt>\r\n  <dd>Ionic</dd>\r\n</dl>',	'2021-03-03 23:51:25');

DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject` varchar(100) DEFAULT NULL,
  `message` longtext,
  `email` varchar(100) DEFAULT NULL,
  `closed` bit(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `contact` (`id`, `subject`, `message`, `email`, `closed`, `createdAt`) VALUES
(2,	'Leaking street',	'There is a street damaged and I couldn\'t find find the proper option on this site. Can someone help me addrees the issue?',	'adam@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-16 20:04:08'),
(34,	'Blocked roads',	'All roads in my neighbor are blocked due to no collection.',	'seth@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-16 20:04:08'),
(35,	'Lighting not working properly',	'I cound\'t find the proper option in the app to address this issue. Lights are not working properly in my street. ',	'john@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-16 20:04:08'),
(36,	'Fail on app',	'App not working ok.',	'thomaz@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-16 20:04:08'),
(37,	'App freeze',	'I can\'t use app in my mobile. It is a android an it is not working.',	'pell@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-16 20:04:08'),
(38,	'Site not give right info',	'I\'ve been trying connect to you guys to advise some information are not ok.',	'pell@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-16 20:04:08'),
(39,	'App failing',	'I can\'t use app in my mobile. It is a android an it is not working.',	'pell@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-16 20:04:08'),
(40,	'Infos!',	'I need infos for my school project and I think you can provide some help. Can someone help me.',	'tomtom@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-19 20:04:08'),
(41,	'Gargage issue',	'How can I inform plenty collection issue in my street? ',	'donnah@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-19 20:04:08'),
(42,	'Extra data',	'I need some additional data for my reports.',	'donna@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-21 20:04:08'),
(43,	'Down down',	'Site not available. No body can access.',	'timton@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-24 20:04:08'),
(44,	'help',	'I need some additional data for my reports.',	'donna@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-24 20:04:08');

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `description` longtext,
  `closed` bit(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `news` (`id`, `title`, `description`, `closed`, `createdAt`) VALUES
(1,	'First version available',	'Admin and app version available for test. enjoy the new experience and report any issue.',	CONV('0', 2, 10) + 0,	'2021-03-16 20:40:59'),
(2,	'Conceiptual purpose',	'In order to understand better the purpose of this project, we found out a link to a article where detail of the concepts can be found. \r\nAccess and understand better.<br><a href=\'https://theconversation.com/smart-cities-worlds-best-dont-just-adopt-new-technology-they-make-it-work-for-people-124939\' target=\'_blank\'>Link to the news</a>',	CONV('0', 2, 10) + 0,	'2021-03-16 20:41:30'),
(3,	'Smart city make it better or worse?',	'The smart city vision has also been criticised for its focus on the control and surveillance of ordinary citizens.<br>\r\n<a href=\'https://theconversation.com/will-indias-experiment-with-\r\nsmart-cities-tackle-poverty-or-make-it-worse-53678\' target=\'_blank\'>Link to the news</a>',	CONV('0', 2, 10) + 0,	'2021-03-16 20:41:57');

DROP TABLE IF EXISTS `ocorrency`;
CREATE TABLE `ocorrency` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `closed` bit(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `ocorrency` (`id`, `name`, `description`, `closed`, `createdAt`) VALUES
(1,	'Sewage',	'Sewage Collection and Treatment',	CONV('0', 2, 10) + 0,	'2021-03-15 14:33:48'),
(2,	'Drinking Water',	'Drinking Water System',	CONV('0', 2, 10) + 0,	'2021-03-22 17:43:42'),
(3,	'Street lighting',	'Street lighting system',	CONV('0', 2, 10) + 0,	'2021-03-22 17:44:06'),
(4,	'Sidewalks',	'Sidewalks ',	CONV('0', 2, 10) + 0,	'2021-03-22 17:44:31'),
(5,	'Asphalt',	'Asphalt',	CONV('0', 2, 10) + 0,	'2021-03-22 17:44:47'),
(6,	'Urban Cleaning',	'Urban Cleaning System',	CONV('0', 2, 10) + 0,	'2021-03-22 17:45:14');

DROP TABLE IF EXISTS `ocorrencyDetail`;
CREATE TABLE `ocorrencyDetail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL,
  `ocorrencyId` int NOT NULL,
  `closed` bit(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ocorrencyId` (`ocorrencyId`),
  CONSTRAINT `ocorrencyDetail_ibfk_1` FOREIGN KEY (`ocorrencyId`) REFERENCES `ocorrency` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `ocorrencyDetail` (`id`, `description`, `ocorrencyId`, `closed`, `createdAt`) VALUES
(1,	'Smell',	1,	CONV('0', 2, 10) + 0,	'2021-03-15 14:34:26'),
(2,	'Leaking',	1,	CONV('0', 2, 10) + 0,	'2021-03-22 17:47:54'),
(3,	'Leaking',	2,	CONV('0', 2, 10) + 0,	'2021-03-22 17:49:00'),
(4,	'Unavailable',	2,	CONV('0', 2, 10) + 0,	'2021-03-22 17:49:23'),
(5,	'Unavailable',	3,	CONV('0', 2, 10) + 0,	'2021-03-22 17:49:53'),
(6,	'Intermitent',	3,	CONV('0', 2, 10) + 0,	'2021-03-22 17:50:15'),
(7,	'Bad condition',	4,	CONV('0', 2, 10) + 0,	'2021-03-22 17:50:45'),
(8,	'Blocked',	4,	CONV('0', 2, 10) + 0,	'2021-03-22 17:51:30'),
(9,	'Bad condition',	5,	CONV('0', 2, 10) + 0,	'2021-03-22 17:52:15'),
(10,	'Blocking way',	6,	CONV('0', 2, 10) + 0,	'2021-03-22 17:52:57'),
(11,	'Needed',	6,	CONV('0', 2, 10) + 0,	'2021-03-22 17:53:14');

DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `longitude` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `latitude` varchar(24) NOT NULL,
  `ocorrency` int NOT NULL,
  `ocorrencyDetail` int NOT NULL,
  `orderStatus` int NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ocorrency` (`ocorrency`),
  KEY `ocorrencyDetail` (`ocorrencyDetail`),
  KEY `orderStatus` (`orderStatus`),
  CONSTRAINT `order_ibfk_5` FOREIGN KEY (`ocorrency`) REFERENCES `ocorrency` (`id`),
  CONSTRAINT `order_ibfk_6` FOREIGN KEY (`ocorrencyDetail`) REFERENCES `ocorrencyDetail` (`id`),
  CONSTRAINT `order_ibfk_7` FOREIGN KEY (`orderStatus`) REFERENCES `orderStatus` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `order` (`id`, `longitude`, `latitude`, `ocorrency`, `ocorrencyDetail`, `orderStatus`, `createdAt`) VALUES
(1,	'-46.87084744984179',	'-23.508235442701796',	3,	3,	4,	'2021-03-24 17:31:35'),
(2,	'-46.83033536632648',	'-23.50933733575509',	2,	2,	4,	'2021-03-24 17:37:11');

DROP TABLE IF EXISTS `orderStatus`;
CREATE TABLE `orderStatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `closed` bit(1) NOT NULL,
  `createdAt` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `orderStatus` (`id`, `name`, `closed`, `createdAt`) VALUES
(1,	'open',	CONV('0', 2, 10) + 0,	'2021-03-15 13:42:56'),
(2,	'In analisys',	CONV('0', 2, 10) + 0,	'2021-03-22 17:53:43'),
(3,	'In execution',	CONV('0', 2, 10) + 0,	'2021-03-22 17:54:52'),
(4,	'Done',	CONV('0', 2, 10) + 0,	'2021-03-22 17:54:14'),
(5,	'Cancelled',	CONV('0', 2, 10) + 0,	'2021-03-22 17:54:33');

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `createdAt` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `role` (`id`, `name`, `description`, `createdAt`) VALUES
(1,	'admin',	'',	'2021-03-15 13:42:34');

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `userName` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `active` bit(1) NOT NULL DEFAULT b'1',
  `block` bit(1) NOT NULL DEFAULT b'0',
  `roleId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `roleId` (`roleId`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `user` (`id`, `firstName`, `lastName`, `userName`, `password`, `active`, `block`, `roleId`, `createdAt`) VALUES
(3,	'Tiago',	'Eduardo',	'tiago.eduardo',	'202CB962AC59075B964B07152D234B70',	CONV('1', 2, 10) + 0,	CONV('0', 2, 10) + 0,	1,	'2021-03-15 13:43:11'),
(6,	'Tiago',	'Eduardo',	'tiago.eduardo.3',	'123',	CONV('0', 2, 10) + 0,	CONV('0', 2, 10) + 0,	1,	'2021-03-15 14:30:39');

-- 2021-03-24 17:55:47
