-- Adminer 4.7.8 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `tebecity` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `tebecity`;

DROP TABLE IF EXISTS `ocorrency`;
CREATE TABLE `ocorrency` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `ocorrency` (`id`, `name`, `description`, `createdAt`) VALUES
(3,	'Esgoto',	'Serviço de Rede Esgoto',	'2021-01-21 00:20:48');

DROP TABLE IF EXISTS `ocorrencyDetail`;
CREATE TABLE `ocorrencyDetail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL,
  `ocorrencyId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ocorrencyId` (`ocorrencyId`),
  CONSTRAINT `ocorrencyDetail_ibfk_1` FOREIGN KEY (`ocorrencyId`) REFERENCES `ocorrency` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `ocorrencyDetail` (`id`, `description`, `ocorrencyId`, `createdAt`) VALUES
(2,	'Esgoto vazando',	3,	'2021-01-21 00:21:31');

DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `longitude` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `latitude` varchar(24) NOT NULL,
  `ocorrencyId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ocorrencyId` (`ocorrencyId`),
  CONSTRAINT `order_ibfk_2` FOREIGN KEY (`ocorrencyId`) REFERENCES `ocorrency` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `order` (`id`, `longitude`, `latitude`, `ocorrencyId`, `createdAt`) VALUES
(9,	'0001',	'-1000',	3,	'0001-01-01 00:00:00');

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `userName` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `active` bit(1) NOT NULL DEFAULT b'1',
  `block` bit(1) NOT NULL DEFAULT b'0',
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `user` (`id`, `firstName`, `lastName`, `userName`, `password`, `active`, `block`, `createdAt`) VALUES
(2,	'user 1',	'test 1',	'user1',	'202CB962AC59075B964B07152D234B70',	CONV('1', 2, 10) + 0,	CONV('0', 2, 10) + 0,	'0001-01-01 00:00:00');

-- 2021-03-03 13:55:14
