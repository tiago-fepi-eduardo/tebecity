-- Adminer 4.7.8 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `tebecity` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `tebecity`;

DROP TABLE IF EXISTS `about`;
CREATE TABLE `about` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `description` longtext,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `about` (`id`, `title`, `description`, `createdAt`) VALUES
(1,	'Loren ipsun title',	'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',	'2021-03-03 23:51:25');

DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject` varchar(100) DEFAULT NULL,
  `message` longtext,
  `email` varchar(100) DEFAULT NULL,
  `closed` bit(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `contact` (`id`, `subject`, `message`, `email`, `closed`, `createdAt`) VALUES
(2,	'assunto11',	'loren11',	'loren11@mail.com',	CONV('0', 2, 10) + 0,	'2021-03-15 20:00:39'),
(3,	'lore',	'loren ipsun laren.',	'tiago@bol',	CONV('0', 2, 10) + 0,	'2021-03-15 20:00:11'),
(4,	'lore',	'lorein loreeenn lorein loreeenn lorein loreeenn lorein loreeennlorein loreeenn lorein loreeenn lorein loreeenn lorein loreeenn lorein loreeennlorein loreeennlorein loreeenn lorein loreeennlorein loreeennlorein loreeennlorein loreeennlorein loreeennlorein loreeennlorein loreeennlorein loreeenn lorein loreeenn lorein loreeennlorein loreeennlorein loreeenn',	'tiago.eduardo@outlook.com.br',	CONV('0', 2, 10) + 0,	'2021-03-15 19:56:32');

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `description` longtext,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `ocorrency`;
CREATE TABLE `ocorrency` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `ocorrency` (`id`, `name`, `description`, `createdAt`) VALUES
(1,	'Iluminação',	'Iluminação de vias.',	'2021-03-15 14:33:48');

DROP TABLE IF EXISTS `ocorrencyDetail`;
CREATE TABLE `ocorrencyDetail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL,
  `ocorrencyId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ocorrencyId` (`ocorrencyId`),
  CONSTRAINT `ocorrencyDetail_ibfk_1` FOREIGN KEY (`ocorrencyId`) REFERENCES `ocorrency` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `ocorrencyDetail` (`id`, `description`, `ocorrencyId`, `createdAt`) VALUES
(1,	'Luz apagada',	1,	'2021-03-15 14:34:26');

DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `longitude` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `latitude` varchar(24) NOT NULL,
  `ocorrencyId` int NOT NULL,
  `ocorrencyDetailId` int NOT NULL,
  `orderStatusId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ocorrencyId` (`ocorrencyId`),
  KEY `ocorrencyDetailId` (`ocorrencyDetailId`),
  KEY `orderStatusId` (`orderStatusId`),
  CONSTRAINT `order_ibfk_2` FOREIGN KEY (`ocorrencyId`) REFERENCES `ocorrency` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_ibfk_3` FOREIGN KEY (`ocorrencyDetailId`) REFERENCES `ocorrencyDetail` (`id`),
  CONSTRAINT `order_ibfk_4` FOREIGN KEY (`orderStatusId`) REFERENCES `orderStatus` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `order` (`id`, `longitude`, `latitude`, `ocorrencyId`, `ocorrencyDetailId`, `orderStatusId`, `createdAt`) VALUES
(2,	'12312313',	'545',	1,	1,	1,	'2021-03-15 14:34:54');

DROP TABLE IF EXISTS `orderStatus`;
CREATE TABLE `orderStatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `createdAt` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `orderStatus` (`id`, `name`, `createdAt`) VALUES
(1,	'open',	'2021-03-15 13:42:56');

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `createdAt` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `role` (`id`, `name`, `description`, `createdAt`) VALUES
(1,	'admin',	'',	'2021-03-15 13:42:34');

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `userName` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `active` bit(1) NOT NULL DEFAULT b'1',
  `block` bit(1) NOT NULL DEFAULT b'0',
  `roleId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `roleId` (`roleId`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `user` (`id`, `firstName`, `lastName`, `userName`, `password`, `active`, `block`, `roleId`, `createdAt`) VALUES
(3,	'Tiago',	'Eduardo',	'tiago.eduardo',	'202CB962AC59075B964B07152D234B70',	CONV('1', 2, 10) + 0,	CONV('0', 2, 10) + 0,	1,	'2021-03-15 13:43:11'),
(6,	'Tiago',	'Eduardo',	'tiago.eduardo.3',	'123',	CONV('0', 2, 10) + 0,	CONV('0', 2, 10) + 0,	1,	'2021-03-15 14:30:39');

-- 2021-03-15 21:34:22
